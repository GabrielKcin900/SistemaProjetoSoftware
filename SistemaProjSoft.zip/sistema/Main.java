import java.util.Scanner;

class Main
{
  public static void main(String args[])
  {
      System.out.printf("BEM VINDO AO IFace\n");
      while(true)
      {
          System.out.printf("BEM VINDO AO IFace\n");
          System.out.printf("O que desejas fazer?\n");
          System.out.printf("1 - Criar uma Conta?\n2 - Fazer Login\n");
          Scanner recebe = new Scanner(System.in);
          int escolha = recebe.nextInt();
          if(escolha == 1)
          {
            RecebendoDados d = new RecebendoDados();
            d.recebaInformacao();
          }
          else if(escolha == 2)
          {
              //Recolha as informações do usuário e verifique se ele existe no vetor de usuários
          }
          else
          {
              
          }
      }  
  }
    
  
}
