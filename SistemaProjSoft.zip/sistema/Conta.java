public class Conta
{
   public String login;
   public String senha;
   public String nick;

   public void setInformation(String alogin, String asenha, String anick)
  {
      this.login = alogin;
      this.senha = asenha;
      this.nick = anick;
  }

  public String getLogin()
  {
    return login;
  }

  public String getSenha()
  {
    return senha;
  }

  public String getNick()
  {
    return nick;
  }
  
}