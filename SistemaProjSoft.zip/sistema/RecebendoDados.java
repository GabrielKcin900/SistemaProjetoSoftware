import java.util.Scanner;
import java.util.ArrayList;

public class RecebendoDados
{
     public void recebaInformacao()
     {
        System.out.printf("\n\nCRIANDO CONTA\n\n");
       
        ArrayList<Conta> vetorusuario = new ArrayList();

        String a, b, c;
    
        Scanner captura = new Scanner(System.in);
    
        System.out.print("Digite seu Login: ");
        a = captura.next();
        System.out.print("Digite sua Senha: ");
        b = captura.next();
        System.out.print("Digite seu Nickname: ");
        c = captura.next();

       Conta t = new Conta();
       t.setInformation(a, b, c);
        
       vetorusuario.add(t);
    
       System.out.print("\n\nSEUS DADOS SÃO ESSES\n");
       System.out.print("Login: " + t.login + "\nSenha: " + t.senha + "\nNick: " + t.nick + "\n\n");
    }   
}